var wms_layers = [];

var format_Northeastgeo_0 = new ol.format.GeoJSON();
var features_Northeastgeo_0 = format_Northeastgeo_0.readFeatures(json_Northeastgeo_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Northeastgeo_0 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_Northeastgeo_0.addFeatures(features_Northeastgeo_0);
var lyr_Northeastgeo_0 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_Northeastgeo_0, 
                style: style_Northeastgeo_0,
                popuplayertitle: "North east geo",
                interactive: true,
    title: 'North east geo<br />\
    <img src="styles/legend/Northeastgeo_0_0.png" /> Albien-Cénomanien<br />\
    <img src="styles/legend/Northeastgeo_0_1.png" /> Aptien<br />\
    <img src="styles/legend/Northeastgeo_0_2.png" /> Berriasien-Aptien<br />\
    <img src="styles/legend/Northeastgeo_0_3.png" /> Campanien-Maastrichtien<br />\
    <img src="styles/legend/Northeastgeo_0_4.png" /> Eocène inférieur<br />\
    <img src="styles/legend/Northeastgeo_0_5.png" /> Eocène supérieur<br />\
    <img src="styles/legend/Northeastgeo_0_6.png" /> Jurassique<br />\
    <img src="styles/legend/Northeastgeo_0_7.png" /> Langhien-Serravallien<br />\
    <img src="styles/legend/Northeastgeo_0_8.png" /> Maastrichtien-Paléocène<br />\
    <img src="styles/legend/Northeastgeo_0_9.png" /> Messinien-Pliocène<br />\
    <img src="styles/legend/Northeastgeo_0_10.png" /> Miocène inférieur marin<br />\
    <img src="styles/legend/Northeastgeo_0_11.png" /> Oligocène<br />\
    <img src="styles/legend/Northeastgeo_0_12.png" /> Oligocène inférieur<br />\
    <img src="styles/legend/Northeastgeo_0_13.png" /> Oligocène supérieur<br />\
    <img src="styles/legend/Northeastgeo_0_14.png" /> Oligocène supérieur-Miocène inférieur<br />\
    <img src="styles/legend/Northeastgeo_0_15.png" /> Pliocène marin<br />\
    <img src="styles/legend/Northeastgeo_0_16.png" /> Quaternaire<br />\
    <img src="styles/legend/Northeastgeo_0_17.png" /> Quaternaire continentale<br />\
    <img src="styles/legend/Northeastgeo_0_18.png" /> Quaternaire-Tyrrhénien<br />\
    <img src="styles/legend/Northeastgeo_0_19.png" /> Roche Volcanique<br />\
    <img src="styles/legend/Northeastgeo_0_20.png" /> Serravallien-Tortonien<br />\
    <img src="styles/legend/Northeastgeo_0_21.png" /> Trias<br />\
    <img src="styles/legend/Northeastgeo_0_22.png" /> Turonien<br />\
    <img src="styles/legend/Northeastgeo_0_23.png" /> Turonien-Santonien<br />\
    <img src="styles/legend/Northeastgeo_0_24.png" /> Valanginien-Aptien<br />\
    <img src="styles/legend/Northeastgeo_0_25.png" /> <br />'
        });

lyr_Northeastgeo_0.setVisible(true);
var layersList = [lyr_Northeastgeo_0];
lyr_Northeastgeo_0.set('fieldAliases', {'OBJECTID': 'OBJECTID', 'Code': 'Code', 'CHRONO': 'CHRONO', 'NOM_FOR': 'NOM_FOR', 'DES_PET': 'DES_PET', 'PERMEA': 'PERMEA', 'Shape_Leng': 'Shape_Leng', 'CCFP': 'CCFP', 'Shape_Le_1': 'Shape_Le_1', 'Shape_Le_2': 'Shape_Le_2', 'Shape_Area': 'Shape_Area', });
lyr_Northeastgeo_0.set('fieldImages', {'OBJECTID': 'TextEdit', 'Code': 'TextEdit', 'CHRONO': 'TextEdit', 'NOM_FOR': 'TextEdit', 'DES_PET': 'TextEdit', 'PERMEA': 'TextEdit', 'Shape_Leng': 'TextEdit', 'CCFP': 'TextEdit', 'Shape_Le_1': 'TextEdit', 'Shape_Le_2': 'TextEdit', 'Shape_Area': 'TextEdit', });
lyr_Northeastgeo_0.set('fieldLabels', {'OBJECTID': 'no label', 'Code': 'no label', 'CHRONO': 'no label', 'NOM_FOR': 'no label', 'DES_PET': 'no label', 'PERMEA': 'no label', 'Shape_Leng': 'no label', 'CCFP': 'no label', 'Shape_Le_1': 'no label', 'Shape_Le_2': 'no label', 'Shape_Area': 'no label', });
lyr_Northeastgeo_0.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});